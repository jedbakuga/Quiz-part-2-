import React from 'react';

import ShareButton from './index';

export default {
  component: ShareButton,
  title: 'Components/ShareButton',
} 

export const Share = () => <ShareButton/>;