# quiz-app
 
 -open cmd
 -run npm install
 -then run npm start
-open chrome http://localhost:3000/quiz-app